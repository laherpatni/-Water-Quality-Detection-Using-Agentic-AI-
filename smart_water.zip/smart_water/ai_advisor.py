# ai_advisor.py
import os
import json
import pandas as pd
import numpy as np
import streamlit as st
from typing import Optional

# OpenAI client
try:
    import openai
except Exception:
    openai = None

# -------------------------
# Helpers: API key & model
# -------------------------
def _get_openai_key():
    try:
        if st.secrets and "openai" in st.secrets and "api_key" in st.secrets["openai"]:
            return st.secrets["openai"]["api_key"]
    except Exception:
        pass
    return os.environ.get("OPENAI_API_KEY", None)

def _get_model_name():
    try:
        if st.secrets and "openai" in st.secrets and "model" in st.secrets["openai"]:
            return st.secrets["openai"]["model"]
    except Exception:
        pass
    return os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

# -------------------------
# Build compact safe dataframe context
# -------------------------
def build_dataframe_context(df: pd.DataFrame, max_rows_sample: int = 6) -> str:
    if df is None or df.empty:
        return "Dataset: (no data supplied)\n"

    parts = []
    parts.append(f"Rows: {len(df)}, Columns: {len(df.columns)}")

    # column types + missing counts
    dtypes = df.dtypes.astype(str).to_dict()
    missing = df.isnull().sum().to_dict()
    col_lines = [f"{c} (type={dtypes[c]}, missing={int(missing[c])})" for c in df.columns]
    parts.append("Columns: " + ", ".join(col_lines))

    # numeric summaries (min, mean, max)
    numeric = df.select_dtypes(include=[np.number])
    if not numeric.empty:
        num_desc = numeric.describe().T[["min", "mean", "max"]].round(4)
        parts.append("Numeric summary (min, mean, max):")
        for col in num_desc.index[:8]:
            r = num_desc.loc[col]
            parts.append(f" - {col}: min={r['min']}, mean={r['mean']}, max={r['max']}")

    # date info
    date_cols = [c for c in df.columns if "date" in c.lower() or np.issubdtype(df[c].dtype, np.datetime64)]
    if date_cols:
        try:
            dcol = date_cols[0]
            df_temp = df.copy()
            df_temp[dcol] = pd.to_datetime(df_temp[dcol], errors="coerce")
            parts.append(f"Date column: {dcol}, range: {df_temp[dcol].min()} -> {df_temp[dcol].max()}")
        except Exception:
            pass

    # sample rows
    n = len(df)
    if n <= max_rows_sample:
        sample = df
    else:
        head = df.head(max_rows_sample//2)
        tail = df.tail(max_rows_sample//2)
        sample = pd.concat([head, tail]).drop_duplicates().head(max_rows_sample)

    try:
        sample_csv = sample.astype(str).to_csv(index=False, line_terminator=" | ")
        parts.append("Example rows (CSV-like, truncated):")
        parts.append(sample_csv[:1600])
    except Exception:
        pass

    return "\n".join(parts)

# -------------------------
# Core LLM call wrapper
# -------------------------
def call_openai_chat(messages, model_name: Optional[str], max_tokens: int = 800, temperature: float = 0.2):
    global openai
    if openai is None:
        try:
            import openai as _openai
            openai = _openai
        except Exception as e:
            raise RuntimeError("OpenAI package not installed. Run `pip install openai`.") from e

    api_key = _get_openai_key()
    if not api_key:
        raise RuntimeError("OpenAI API key not found. Put it in .streamlit/secrets.toml or OPENAI_API_KEY env var.")

    openai.api_key = api_key

    response = openai.ChatCompletion.create(
        model=model_name,
        messages=messages,
        max_tokens=max_tokens,
        temperature=temperature
    )
    return response

# -------------------------
# Main function used by app
# -------------------------
def ask_ai_advisor(df: pd.DataFrame, user_query: str, keep_history: bool = True) -> str:
    """
    Query the LLM with concise dataset context and user's question.
    Returns descriptive answers + actionable recommendations.
    """
    if user_query is None or str(user_query).strip() == "":
        return "Ask a question about your dataset."

    model_name = _get_model_name()
    api_key = _get_openai_key()
    if not api_key:
        return ("OpenAI API key not found. Add to .streamlit/secrets.toml: "
                "[openai]\\napi_key = \"sk-...\"\\nmodel = \"gpt-4o-mini\"")

    # build dataset context
    df_context = build_dataframe_context(df)

    # descriptive system prompt
    system_prompt = (
        "You are an expert water-quality scientist and advisor. "
        "Always give detailed and descriptive explanations that help the user understand trends, causes, and implications. "
        "Provide actionable recommendations (1-3 items) clearly labeled at the end. "
        "If the user asks for code, charts, or calculations, provide correct Python/pandas/plotly snippets. "
        "Use the dataset context only, and mention if additional data is needed to answer fully. "
        "Be professional, informative, and explanatory, not just brief."
    )

    if "ai_chat_history" not in st.session_state or not keep_history:
        st.session_state.ai_chat_history = []

    # Append system context only once
    if not any(m.get("role") == "system" for m in st.session_state.ai_chat_history):
        st.session_state.ai_chat_history.append({"role": "system", "content": system_prompt})
        st.session_state.ai_chat_history.append({"role": "system", "content": "Dataset context:\n" + df_context})

    # Add user message
    user_message = {"role": "user", "content": user_query}
    st.session_state.ai_chat_history.append(user_message)

    # Trim history for performance
    history = st.session_state.ai_chat_history.copy()
    if len(history) > 20:
        system_msgs = [m for m in history if m["role"] == "system"]
        user_ai_tail = history[-12:]
        history = system_msgs + user_ai_tail

    # Call OpenAI
    try:
        with st.spinner("🤖 AI is analyzing your dataset..."):
            response = call_openai_chat(history, model_name=model_name, max_tokens=800, temperature=0.2)
    except Exception as e:
        err = f"Error calling OpenAI API: {e}"
        st.error(err)
        return err

    # Parse assistant output
    assistant_text = ""
    try:
        assistant_text = response["choices"][0]["message"]["content"].strip()
    except Exception:
        assistant_text = "No answer returned by the model."

    # Append assistant to history
    st.session_state.ai_chat_history.append({"role": "assistant", "content": assistant_text})

    # Extract Python code snippet if present
    code_snippet = None
    if "```python" in assistant_text:
        try:
            start = assistant_text.index("```python") + len("```python")
            end = assistant_text.index("```", start)
            code_snippet = assistant_text[start:end].strip()
        except Exception:
            code_snippet = None

    if code_snippet:
        st.session_state.ai_last_code = code_snippet
    else:
        st.session_state.ai_last_code = None

    return assistant_text

# Optional helper to return the code from last AI response
def get_last_response_code() -> str:
    import streamlit as st
    return st.session_state.get("ai_last_code", None)

