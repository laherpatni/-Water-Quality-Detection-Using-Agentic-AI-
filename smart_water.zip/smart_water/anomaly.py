# anomaly.py
import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
from sklearn.ensemble import IsolationForest
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from model_utils import train_xgb_model_for_param, load_combined_user_data
import requests  # Added for Green API

# Optional: Twilio and Email for production (disabled in testing)
try:
    from app import ENABLE_EMAIL  # Flag from main app
except ImportError:
    ENABLE_EMAIL = False

ENABLE_ALERTS = ENABLE_EMAIL  # Use same flag for both email & WhatsApp for testing

# -------------------- GREEN API CONFIG --------------------
GREEN_API_INSTANCE_ID = "7105400246"  # replace with your Green API instance ID
GREEN_API_TOKEN = "015a7395365e4b4c934b1b8c827f88b478355d2ac9f94606aa"  # replace with your Green API token
TEST_PHONE_NUMBER = "+919822774209"  # recipient

def send_whatsapp_alert(message, phone_number):
    """
    Send WhatsApp message via Green API
    """
    if not ENABLE_ALERTS:
        st.info(f"[WhatsApp Disabled] Would have sent: {message}")
        return

    url = f"https://api.green-api.com/waInstance{GREEN_API_INSTANCE_ID}/sendMessage/{GREEN_API_TOKEN}"
    payload = {
        "chatId": f"{phone_number.replace('+','')}@c.us",
        "message": message
    }
    try:
        resp = requests.post(url, json=payload)
        if resp.status_code == 200:
            st.success(f"WhatsApp message sent to {phone_number}")
        else:
            st.error(f"Failed to send WhatsApp message: {resp.text}")
    except Exception as e:
        st.error(f"Error sending WhatsApp message: {e}")

# -------------------- EMAIL REPORT --------------------
def send_email_report(to_email, report_path):
    if not ENABLE_ALERTS:
        st.info(f"[Email Disabled] Would have sent report to {to_email}")
        return

    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from email.mime.application import MIMEApplication
    import os

    EMAIL_SENDER = "vivekdokre@gmail.com"  # Sender email
    EMAIL_PASSWORD = "yrsu qlrq lgzv oixo"   # Gmail app password
    TEST_EMAIL_RECIPIENT = "rohpatil2005@gmail.com"  # Recipient for test

    msg = MIMEMultipart()
    msg['From'] = EMAIL_SENDER
    msg['To'] = to_email
    msg['Subject'] = "Monthly Water Quality Anomaly Report"

    body = "Please find attached the monthly anomaly report for water quality predictions."
    msg.attach(MIMEText(body, 'plain'))

    with open(report_path, "rb") as f:
        attach = MIMEApplication(f.read(), _subtype="pdf")
        attach.add_header('Content-Disposition','attachment', filename=os.path.basename(report_path))
        msg.attach(attach)

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.send_message(msg)
        server.quit()
        st.success(f"Report emailed to {to_email}")
    except Exception as e:
        st.error(f"Error sending email: {e}")

# -------------------- PDF REPORT --------------------
def generate_pdf_report(df, file_path):
    doc = SimpleDocTemplate(file_path)
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph("Monthly Water Quality Anomaly Report", styles['Title']))
    elements.append(Spacer(1, 12))

    for index, row in df.iterrows():
        text = f"Date: {row['Date'].strftime('%Y-%m-%d')}, Parameter: {row['Parameter']}, Value: {row['Value']:.2f}, Status: {row['Status']}"
        elements.append(Paragraph(text, styles['Normal']))
        elements.append(Spacer(1, 6))

    doc.build(elements)

# -------------------- ANOMALY DETECTION UI --------------------
def build_anomaly_ui(user_email, future_predictions, enable_sim=None, scenario_inputs=None):
    st.markdown("### ⚠️ Anomaly Detection on Future Predictions")

    if future_predictions.empty:
        st.info("No future predictions available. Run AI Prediction first.")
        return

    numeric_cols = [col for col in future_predictions.columns if col not in ["Date"] and not col.endswith("_Status")]
    anomalies_summary = []

    for col in numeric_cols:
        data = future_predictions[[col]].values
        iso = IsolationForest(contamination=0.1, random_state=42)
        try:
            iso.fit(data)
            preds = iso.predict(data)
            future_predictions[f"{col}_Anomaly"] = np.where(preds==-1, "⚠️ Anomaly", "✅ Normal")
            anomaly_count = (preds==-1).sum()
            anomalies_summary.append((col, anomaly_count))
        except Exception as e:
            st.warning(f"Anomaly detection failed for {col}: {e}")

    # Display anomaly table
    anomaly_cols = ["Date"] + [col for col in future_predictions.columns if "_Anomaly" in col]
    st.dataframe(future_predictions[anomaly_cols], use_container_width=True)

    # Send WhatsApp for anomalies
    for col, count in anomalies_summary:
        if count > 0:
            send_whatsapp_alert(f"{count} anomalies detected in {col} for future predictions.", TEST_PHONE_NUMBER)

    # Generate PDF report
    pdf_path = f"monthly_anomaly_report_{datetime.now().strftime('%Y%m%d')}.pdf"
    report_df = pd.DataFrame(columns=["Date", "Parameter", "Value", "Status"])
    for col in numeric_cols:
        temp = future_predictions[["Date", col, f"{col}_Anomaly"]].copy()
        temp.columns = ["Date", "Value", "Status"]
        temp["Parameter"] = col
        report_df = pd.concat([report_df, temp], ignore_index=True)

    generate_pdf_report(report_df, pdf_path)
    st.success(f"Monthly anomaly report generated: {pdf_path}")

    # Send Email
    send_email_report(user_email, pdf_path)

    # Test Notifications
    st.markdown("---")
    st.markdown("### ⚡ Test Notifications")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Send Test WhatsApp"):
            send_whatsapp_alert("This is a test WhatsApp message from Smart Water Dashboard.", TEST_PHONE_NUMBER)
    with col2:
        if st.button("Send Test Email"):
            send_email_report(TEST_EMAIL_RECIPIENT, pdf_path)
