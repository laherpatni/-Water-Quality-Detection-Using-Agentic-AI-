import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import xgboost as xgb
import base64
import re
import os
import pickle
# Assuming ai_advisor and anomaly modules exist and work as expected
from ai_advisor import ask_ai_advisor, get_last_response_code
from anomaly import build_anomaly_ui

# Assuming database module exists and contains the necessary functions
from database import create_user, authenticate_user, get_user, save_dataset, get_datasets, get_dataset_by_id

ENABLE_EMAIL = False

# -------------------- CONFIG --------------------
st.set_page_config(page_title="💧 Smart Water Dashboard", layout="wide", initial_sidebar_state="expanded")

# -------------------- MODEL CACHE DIR --------------------
MODEL_DIR = "/tmp/smart_water_models"
os.makedirs(MODEL_DIR, exist_ok=True)

# -------------------- BACKGROUND IMAGE --------------------
@st.cache_data
def get_base64_of_bin_file(bin_file):
    try:
        with open(bin_file, 'rb') as f:
            data = f.read()
        return base64.b64encode(data).decode()
    except FileNotFoundError:
        st.error(f"File not found: {bin_file}. Please ensure it is in the same directory as the script.")
        return None

background_image_path = 'water 2.jpg'
encoded_image = get_base64_of_bin_file(background_image_path)
if encoded_image:
    st.markdown(f"""
        <style>
        .stApp {{
            background-image: url("data:image/jpeg;base64,{encoded_image}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }}
        .stApp::before {{
            content: '';
            position: fixed;
            top:0; left:0;
            width:100%; height:100%;
            /* Semi-transparent white overlay */
            background: rgba(255,255,255,0.9); 
            z-index:-1;
        }}
        
        /* *** CRITICAL STYLES TO REMOVE DEFAULT BOX/CONTAINER BACKGROUNDS *** */
        .stApp > header, .stApp > div:first-child > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) {{
            background: transparent !important;
        }}
        
        /* Target the specific container holding the authentication UI */
        section.main .block-container {{
            background: transparent !important;
            padding-top: 50px; /* Add some top padding back for spacing */
            max-width: 900px; /* Keep the content centered and readable */
        }}
        
        /* Target Streamlit's main content area wrapper */
        [data-testid="stVerticalBlock"] {{
            background: transparent !important;
            padding: 0 !important;
        }}
        
        /* Ensure specific text elements stay visible on the background */
        h1, h2, h3, h4, .stMarkdown, .small-note, .auth-title, .auth-sub {{
            color: #0A2342 !important; /* Force text color */
            text-shadow: 0 0px 4px rgba(255, 255, 255, 0.7); /* Subtle white shadow for visibility */
        }}
        
        </style>
        """, unsafe_allow_html=True)

# -------------------- SESSION --------------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user_email" not in st.session_state:
    st.session_state.user_email = ""
if "username" not in st.session_state:
    st.session_state.username = ""
if "auth_mode" not in st.session_state:
    st.session_state.auth_mode = "login"  # "login" or "signup"

# -------------------- HELPER: Combine all user datasets --------------------
@st.cache_data
def load_combined_user_data(user_email: str):
    """
    Fetches all datasets for a user, concatenates them (ignoring errors),
    and returns a combined DataFrame. Cached by user_email.
    """
    try:
        user_datasets = get_datasets(user_email)
        combined_df = pd.DataFrame()
        for d in user_datasets:
            try:
                df_temp, _ = get_dataset_by_id(d['id'])
                if isinstance(df_temp, pd.DataFrame) and not df_temp.empty:
                    combined_df = pd.concat([combined_df, df_temp], ignore_index=True)
            except Exception:
                # skip faulty dataset but continue
                continue
        # Try to reset index and ensure consistent columns
        if not combined_df.empty:
            combined_df = combined_df.reset_index(drop=True)
        return combined_df
    except Exception as e:
        # Return empty df on failure
        return pd.DataFrame()

# -------------------- HELPER: Train or load cached XGB model --------------------
def _model_filename_for(user_email: str, param: str, n_rows: int, last_val: float, seq_len: int):
    safe_email = re.sub(r'[^0-9a-zA-Z]+', '_', user_email)
    safe_param = re.sub(r'[^0-9a-zA-Z]+', '_', param)
    # Use n_rows and last_val as cheap fingerprint — when new data added, these usually change
    fname = f"xgb_{safe_email}_{safe_param}_n{n_rows}_last{round(float(last_val),6)}_s{seq_len}.pkl"
    return os.path.join(MODEL_DIR, fname)

def train_xgb_model_for_param(data: np.ndarray, user_email: str, param: str, seq_len: int = 3):
    """
    Trains an XGBRegressor on a single-parameter time series using a sliding window of length seq_len.
    Caches the trained model to disk with a filename heuristic that changes when number of rows
    or last observed value changes (simple invalidation).
    Returns the trained model or None if not enough data.
    """
    # data is expected shape (n,1)
    if data is None or len(data) < seq_len + 1:
        return None

    n_rows = len(data)
    last_val = float(data[-1, 0])
    model_path = _model_filename_for(user_email, param, n_rows, last_val, seq_len)

    # If cached model file exists, load and return
    if os.path.exists(model_path):
        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)
            return model
        except Exception:
            # If load fails, continue to retrain
            pass

    # Build X, y sliding windows
    X, y = [], []
    for i in range(seq_len, len(data)):
        X.append(data[i - seq_len:i, 0])
        y.append(data[i, 0])
    X = np.array(X)
    y = np.array(y)

    if len(X) == 0:
        return None

    # Train model
    model = xgb.XGBRegressor(n_estimators=200, max_depth=3, learning_rate=0.1, verbosity=0)
    model.fit(X, y)

    # Save model to disk
    try:
        with open(model_path, "wb") as f:
            pickle.dump(model, f)
    except Exception:
        # ignore cache-save errors
        pass

    return model

# -------------------- UPDATED STYLES (Aesthetics & Button Sizing) --------------------
st.markdown(
    """
    <style>
    
    /* Branding */
    .auth-brand {
        display:flex;
        flex-direction:column;
        align-items:center;
        gap:8px;
        margin-bottom:20px; /* Increased margin for spacing */
    }
    .auth-brand-icon {
        font-size:42px; /* Slightly larger icon */
        width:70px;
        height:70px;
        display:flex;
        align-items:center;
        justify-content:center;
        border-radius:16px;
        background: linear-gradient(180deg, #EAF0FF 0%, #F7F9FF 100%);
        box-shadow: 0 8px 20px rgba(45,55,110,0.1);
    }
    .auth-title {
        font-size:36px !important; /* Significantly larger heading */
        font-weight:900;
        margin:0;
        color:#0A2342;
    }
    .auth-sub {
        margin-top:2px;
        color:#687182;
        font-size:16px; /* Slightly larger subtitle */
        text-align:center;
    }

    /* Streamlit inputs */
    .stForm .stTextInput > div > div > input,
    .stForm .stTextArea > div > div > textarea,
    .stForm .stSelectbox > div > div > select {
        border-radius: 12px; /* Rounded corners */
        padding: 14px 16px; /* Increased padding */
        border: 1px solid #C5D0E0;
        width: 100%;
        max-width: 480px; 
        margin: 8px 0;
        display: block;
        box-sizing: border-box;
        background-color: rgba(255, 255, 255, 0.95);
        font-size: 16px; /* Larger font size in input fields */
    }

    /* Input labels spacing */
    .stForm label {
        font-weight:700;
        color:#0A2342;
        display:block;
        margin-top:16px; /* Increased margin above label */
    }

    /* Primary buttons (Sign In / Create Account) */
    .stForm .stButton>button {
        border-radius: 12px;
        padding: 14px 16px; /* Increased padding for size */
        background: linear-gradient(90deg,#5D5BFF,#4B47E0);
        color: white;
        font-weight: 700;
        font-size: 18px; /* Larger text for sign-in button */
        border: none;
        width: 100%;
        max-width: 480px; 
        margin: 16px 0 24px 0; /* Increased margins */
        display:block;
    }
    
    /* Toggle Buttons (Login / Create Account) */
    .stButton[key*="tab"] > button {
        border-radius: 12px;
        padding: 12px 18px; /* Increased padding for size */
        background: #F0F2F6;
        color: #475569;
        font-weight: 600;
        font-size: 16px;
        border: 1px solid #D1D5DB;
        width: 100%;
        transition: all .2s ease;
    }
    
    .stButton[key*="tab"]:hover > button {
        background: #E5E7EB;
    }
    
    /* Small helper text */
    .small-note {
        font-size:14px; /* Slightly larger small text */
        color:#6B7280;
        text-align:center;
        margin-top:8px;
    }

    /* Dashboard-specific styles (kept) */
    .kpi-grid {display:flex; flex-wrap: wrap; gap: 15px; margin-bottom:20px;}
    .kpi-card {flex:1; min-width:150px; padding:15px; border-radius:12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); text-align:center; border: 1px solid #E0E6F0; background:#FFFFFF;}
    .kpi-alert-card {background:#F8D7DA; border-left: 5px solid #DC3545;}
    .kpi-safe-card {background:#D4EDDA; border-left: 5px solid #28A745;}
    .kpi-title {font-size:16px; font-weight:bold; margin-bottom:5px; color:#0A2342;}
    .kpi-alert-text {color:#DC3545;}
    .kpi-safe-text {color:#28A745;}
    .kpi-value {font-size:28px; font-weight:900; color:#0A2342; margin: 4px 0;}
    .kpi-trend {font-size:18px; color:#6C757D;}
    .kpi-minmax {font-size:11px; color:#6C757D; margin-top:5px;}
    .user-bubble {background:#E1F5FE; padding:12px; border-radius:12px; margin:8px 0; border: 1px solid #B3E5FC;}
    .ai-bubble {background:#FFF3CD; padding:12px; border-radius:12px; margin:8px 0; border: 1px solid #FFE0B2;}
    .ai-bubble.alert {background:#F8D7DA; border: 1px solid #DC3545;}
    .ai-bubble.safe {background:#D4EDDA; border: 1px solid #28A745;}
    .dashboard-title {font-size:32px; font-weight:900; text-align:center; margin-bottom:25px; color:#0A2342;}
    
    /* Override Streamlit container padding */
    div[data-testid="stVerticalBlock"] > div:nth-child(1) {
        padding-top: 0;
    }
    
    </style>
    """, unsafe_allow_html=True
)

# -------------------- AUTH UI --------------------
def auth_start_page():
    
    # Use a centered column layout for the authentication UI
    with st.columns([1, 4, 1])[1]: 
        # Branding
        st.markdown("""
            <div class='auth-brand'>
                <div class='auth-brand-icon'>💧</div>
                <div class='auth-title'>Smart Water Dashboard</div>
                <div class='auth-sub'>Monitor, predict and advise — all in one place</div>
            </div>
        """, unsafe_allow_html=True)

        # Toggle buttons
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Login", key="ui_login_tab", use_container_width=True):
                st.session_state.auth_mode = "login"
        with col2:
            if st.button("Create Account", key="ui_signup_tab", use_container_width=True):
                st.session_state.auth_mode = "signup"

        st.markdown("<div class='small-note'>Toggle between Login and Create Account</div>", unsafe_allow_html=True)
        st.write("---")

        if st.session_state.auth_mode == "login":
            login_ui()
        else:
            signup_ui()

def login_ui():
    st.markdown("<div style='padding:4px 0 0 0;'><h3 style='margin:0'>Welcome back</h3></div>", unsafe_allow_html=True)
    st.markdown("<div class='small-note'>Log in to access your dashboard and datasets</div>", unsafe_allow_html=True)

    with st.form("login_form", clear_on_submit=False):
        email = st.text_input("Email", placeholder="you@example.com")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Sign in", use_container_width=True)

    if submit:
        if not email or not password:
            st.error("Please provide both email and password.")
            return

        try:
            ok = authenticate_user(email.strip().lower(), password)
        except Exception as e:
            st.error(f"Error during authentication: {e}")
            return

        if ok:
            st.success("Login successful")
            st.session_state.logged_in = True
            st.session_state.user_email = email.strip().lower()
            user_doc = get_user(st.session_state.user_email)
            if user_doc and "username" in user_doc:
                st.session_state.username = user_doc["username"]
            else:
                st.session_state.username = st.session_state.user_email.split("@")[0]
            st.experimental_rerun()
        else:
            st.error("Invalid email or password. If you don't have an account, create one.")

def signup_ui():
    st.markdown("<div style='padding:4px 0 0 0;'><h3 style='margin:0'>Create an account</h3></div>", unsafe_allow_html=True)
    st.markdown("<div class='small-note'>Start tracking water quality — secure and private</div>", unsafe_allow_html=True)

    with st.form("signup_form", clear_on_submit=False):
        username = st.text_input("Full name", placeholder="Rohan Patil")
        email = st.text_input("Email", placeholder="you@example.com")
        password = st.text_input("Password", type="password", placeholder="At least 8 characters")
        confirm = st.text_input("Confirm Password", type="password")
        submit = st.form_submit_button("Create account", use_container_width=True)

    if submit:
        # Basic validations
        if not username.strip():
            st.error("Please enter your full name.")
            return
        if not email.strip():
            st.error("Please enter an email.")
            return
        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email.strip()):
            st.error("Please enter a valid email address.")
            return
        if not password or len(password) < 8:
            st.error("Password must be at least 8 characters long.")
            return
        if password != confirm:
            st.error("Passwords do not match.")
            return

        try:
            created = create_user(username.strip(), email.strip().lower(), password)
        except Exception as e:
            st.error(f"Error creating user: {e}")
            return

        if not created:
            st.error("An account with that email already exists. Try logging in.")
            return

        st.success("Account created! You are now logged in.")
        st.session_state.logged_in = True
        st.session_state.user_email = email.strip().lower()
        st.session_state.username = username.strip()
        st.experimental_rerun()

# -------------------- MAIN AUTH FLOW --------------------
if not st.session_state.logged_in:
    auth_start_page()

# -------------------- DASHBOARD --------------------
if st.session_state.logged_in:
    # Show username in sidebar and logout
    try:
        display_name = get_user(st.session_state.user_email).get("username", st.session_state.user_email.split("@")[0])
    except Exception:
        display_name = st.session_state.username or st.session_state.user_email
    st.sidebar.success(f"Logged in as **{display_name}**")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.user_email = ""
        st.session_state.username = ""
        st.session_state.auth_mode = "login"
        st.experimental_rerun()

    # -------------------- FILE UPLOAD --------------------
    st.sidebar.markdown("### Upload Water Quality Data")
    uploaded_file = st.file_uploader("Choose a CSV or Excel file", type=["csv", "xls", "xlsx"])

    df = None
    if uploaded_file:
        if uploaded_file.name.endswith(".csv"):
            df = pd.read_csv(uploaded_file)
        elif uploaded_file.name.endswith((".xls", ".xlsx")):
            df = pd.read_excel(uploaded_file)

        # Save dataset to MongoDB
        try:
            dataset_id = save_dataset(st.session_state.user_email, uploaded_file.name, df)
            st.success(f"Dataset saved to your account (ID: {dataset_id})")
            # clear model cache directory for this user to force retrain next time (simple approach)
            # remove files matching this user
            try:
                for fname in os.listdir(MODEL_DIR):
                    if re.sub(r'[^0-9a-zA-Z]+', '_', st.session_state.user_email) in fname:
                        fullp = os.path.join(MODEL_DIR, fname)
                        try:
                            os.remove(fullp)
                        except Exception:
                            pass
            except Exception:
                pass
        except Exception as e:
            st.error(f"Error saving dataset: {e}")

    # -------------------- USER DATASETS --------------------
    st.sidebar.markdown("### Your Saved Datasets")
    try:
        user_datasets = get_datasets(st.session_state.user_email)
    except Exception as e:
        st.error(f"Error fetching datasets: {e}")
        user_datasets = []

    # Prepare list for selectbox
    dataset_options = ["--Select--"] + [d['filename'] for d in user_datasets]
    
    # Check if a dataset was just uploaded and set it as selected
    if uploaded_file and uploaded_file.name in dataset_options:
        default_index = dataset_options.index(uploaded_file.name)
    else:
        default_index = 0
        
    selected_dataset_name = st.sidebar.selectbox("Select a dataset", dataset_options, index=default_index)
    
    if selected_dataset_name != "--Select--":
        for d in user_datasets:
            if d['filename'] == selected_dataset_name:
                try:
                    df, filename = get_dataset_by_id(d['id'])
                    st.info(f"Loaded dataset: **{filename}**")
                except Exception as e:
                    st.error(f"Error loading dataset: {e}")
                    df = None
                break

    # -------------------- DASHBOARD CODE (UNCHANGED) --------------------
    if df is not None and not df.empty:
        # ----- Data Loading and Summary Functions -----
        @st.cache_data
        def get_summary(df):
            return df.describe(include="all").transpose(), df.isnull().sum()

        # ----- KPI DISPLAY FUNCTION -----
        def display_kpis(df, scenario_inputs=None):
            st.markdown("### 📊 Key Water Quality Metrics")
            numeric_cols = df.select_dtypes(include=["int64", "float64"]).columns.tolist()
            if not numeric_cols:
                st.info("No numeric columns to display as KPIs.")
                return
            st.markdown('<div class="kpi-grid">', unsafe_allow_html=True)
            regulatory_limits = {
                "pH": (6.5, 8.5),
                "TDS": (200, 500),
                "Turbidity": (0, 5),
                "Chlorine": (0.2, 1.0),
                "Temperature": (0, 30),
                "Conductivity": (0, 600)
            }
            for col in numeric_cols:
                col_data = df[col].dropna()
                if len(col_data) == 0:
                    continue
                latest_val = float(col_data.iloc[-1])
                if scenario_inputs and col in scenario_inputs:
                    latest_val = scenario_inputs[col]
                prev_val = float(col_data.iloc[-2]) if len(col_data) > 1 else latest_val
                trend = "↑" if latest_val > prev_val else "↓" if latest_val < prev_val else "→"
                card_class = "kpi-card"
                text_class = ""
                limits = None
                for key in regulatory_limits.keys():
                    if key.lower() == col.lower().strip():
                        limits = regulatory_limits[key]
                        break
                if limits:
                    low, high = limits
                    if latest_val < low or latest_val > high:
                        card_class += " kpi-alert-card"
                        text_class = "kpi-alert-text"
                    else:
                        card_class += " kpi-safe-card"
                        text_class = "kpi-safe-text"
                st.markdown(f"""
                <div class="{card_class}">
                    <div class="kpi-title {text_class}">{col}</div>
                    <div class="kpi-value">{latest_val:.2f}</div>
                    <div class="kpi-trend">{trend}</div>
                    <div class="kpi-minmax">Min:{col_data.min():.2f} | Max:{col_data.max():.2f} | Avg:{col_data.mean():.2f}</div>
                </div>
                """, unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        # ----- Sidebar and Tabs -----
        with st.container(border=False):
            st.markdown('<div class="dashboard-title">💧 Smart Water Dashboard</div>', unsafe_allow_html=True)
            tab1, tab2, tab3, tab4, tab5 = st.tabs(["Dashboard", "Data Review", "Prediction", "AI Advisor", "Anomaly Detection"])

            # -------------------- TAB 1: Dashboard & KPIs --------------------
            with tab1:
                filtered_df = df.copy() # Start with a copy
                
                # Date filtering (only if 'Date' column exists)
                if "Date" in df.columns:
                    try:
                        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
                        df = df.dropna(subset=["Date"])
                        min_date, max_date = df["Date"].min(), df["Date"].max()
                        
                        # Handle case where min_date and max_date might be the same (single entry)
                        if min_date == max_date:
                            selected_range = st.date_input("Select Date Range", [min_date, max_date])
                        else:
                            # Ensure the list has two distinct elements for the range slider to work correctly
                            selected_range = st.date_input("Select Date Range", [min_date, max_date])

                        # Ensure selected_range has two elements
                        if len(selected_range) == 2:
                             filtered_df = df[(df["Date"] >= pd.to_datetime(selected_range[0])) & (df["Date"] <= pd.to_datetime(selected_range[1]))]
                        elif len(selected_range) == 1:
                            # Handle case where user selected only one date
                            filtered_df = df[df["Date"] == pd.to_datetime(selected_range[0])]
                        # If range is invalid, keep original df, but it will be handled by checks below
                        
                    except Exception as e:
                        st.warning(f"Could not process 'Date' column for filtering: {e}")
                
                # Ensure filtered_df is not empty after filtering
                if filtered_df.empty:
                    st.warning("No data available for the selected date range.")
                    filtered_df = df.copy() # Fallback to full data if filtering results in empty set
                
                # --- Scenario Simulation ---
                scenario_inputs = {}
                enable_sim = st.checkbox("Enable Scenario Simulation", value=False)
                
                # Use a specific set of parameters for simulation if they exist
                default_sim_params = [c for c in ["pH", "TDS", "Turbidity", "Chlorine"] if c in filtered_df.columns]
                
                if enable_sim and default_sim_params:
                    st.markdown("### 🔧 Scenario Simulation")
                    # Use a column layout for cleaner sliders
                    sim_cols = st.columns(len(default_sim_params)) 
                    for i, param in enumerate(default_sim_params):
                        with sim_cols[i]:
                            col_data = filtered_df[param].dropna()
                            if not col_data.empty:
                                min_val, max_val = col_data.min(), col_data.max()
                                # Handle single point data (min=max)
                                if min_val == max_val:
                                    scenario_inputs[param] = float(min_val)
                                    st.metric(label=f"Adjust {param}", value=f"{min_val:.2f}") # Cannot use slider
                                else:
                                    scenario_inputs[param] = st.slider(f"Adjust {param}", 
                                                                        float(min_val), 
                                                                        float(max_val), 
                                                                        float(col_data.iloc[-1]))
                            
                # Display KPIs
                display_kpis(filtered_df, scenario_inputs)

                # Charts
                st.markdown("### 📈 Data Visualization")
                
                # Define columns for chart controls
                col_chart_type, col_x_axis, col_y_axis = st.columns([1, 1, 1])
                
                all_cols = filtered_df.columns.tolist()
                numeric_cols = filtered_df.select_dtypes(include=["int64", "float64"]).columns.tolist()

                with col_chart_type:
                    chart_type = st.selectbox("Choose chart type:", ["Line", "Bar", "Scatter", "Box", "Heatmap"])
                
                if chart_type != "Heatmap":
                    with col_x_axis:
                        x_axis = st.selectbox("X-axis", all_cols, index=all_cols.index("Date") if "Date" in all_cols else (0 if all_cols else 0))
                    with col_y_axis:
                        # Try to default to 'pH' or first numeric column
                        default_y_index = numeric_cols.index("pH") if "pH" in numeric_cols else (0 if numeric_cols else 0)
                        y_axis = st.selectbox("Y-axis", numeric_cols, index=default_y_index)

                if st.button("Generate Chart", use_container_width=True):
                    if filtered_df.empty:
                        st.warning("The dataset is empty or filtered to be empty.")
                    elif not numeric_cols and chart_type != "Heatmap":
                        st.warning("Cannot generate chart: No numeric columns available for Y-axis.")
                    elif chart_type != "Heatmap" and (not x_axis or not y_axis):
                         st.warning("Please select both X and Y axes.")
                    else:
                        # Downsample for faster rendering if data is large
                        viz_df = filtered_df.sample(2000, random_state=42) if len(filtered_df) > 2000 else filtered_df

                        fig = None
                        if chart_type == "Line" and x_axis and y_axis:
                            fig = px.line(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} over {x_axis}", markers=True)
                        elif chart_type == "Bar" and x_axis and y_axis:
                            fig = px.bar(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} by {x_axis}")
                        elif chart_type == "Scatter" and x_axis and y_axis:
                            fig = px.scatter(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} vs {x_axis}", trendline="ols")
                        elif chart_type == "Box" and x_axis and y_axis:
                            fig = px.box(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} Distribution by {x_axis}")
                        elif chart_type == "Heatmap":
                            if numeric_cols:
                                corr = viz_df[numeric_cols].corr(numeric_only=True)
                                fig = px.imshow(corr, text_auto=True, color_continuous_scale="Blues", title="Correlation Heatmap")
                            else:
                                st.warning("Cannot generate Heatmap: No numeric columns found.")
                        
                        if fig:
                            fig.update_layout(plot_bgcolor='#FFFFFF', paper_bgcolor='#FFFFFF', font_color='#0A2342',
                                                title_font_color='#0A2342', xaxis=dict(showgrid=False, zeroline=False),
                                                yaxis=dict(showgrid=True, zeroline=False, gridcolor='#E9ECEF'))
                            st.plotly_chart(fig, use_container_width=True)


            # -------------------- TAB 2: Data Preview & Summary --------------------
            with tab2:
                st.markdown("### 📋 Data Preview & Summary")
                with st.expander("Show Raw Data"):
                    st.dataframe(filtered_df, use_container_width=True)

                summary_stats, missing_values = get_summary(filtered_df)
                col1_rev, col2_rev = st.columns(2)
                with col1_rev:
                    st.markdown("### Column Types")
                    st.write(filtered_df.dtypes)
                with col2_rev:
                    st.markdown("### Missing Values")
                    st.write(missing_values)

                with st.expander("Show Summary Statistics"):
                    st.dataframe(summary_stats, use_container_width=True)

                st.markdown("### 📥 Download Filtered Data")
                csv = filtered_df.to_csv(index=False).encode("utf-8")
                st.download_button("⬇️ Download Filtered Data as CSV", csv, "filtered_data.csv", "text/csv")

            # -------------------- TAB 3: AI Prediction (combined datasets + cached models) --------------------
            with tab3:
                st.markdown("### 🔮 AI Water Quality Prediction (XGBoost)")

                # Combine all user datasets (not just selected dataset) for prediction
                MAX_ROWS = 5000
                combined_df = load_combined_user_data(st.session_state.user_email)
                future_results = pd.DataFrame()
                
                if combined_df.empty:
                    st.warning("⚠️ No dataset available for prediction. Upload data first.")
                else:
                    df_pred = combined_df.tail(MAX_ROWS).copy() if len(combined_df) > MAX_ROWS else combined_df.copy()

                    if "Date" not in df_pred.columns:
                        st.warning("⚠️ Prediction requires a **'Date'** column.")
                    else:
                        df_pred["Date"] = pd.to_datetime(df_pred["Date"], errors="coerce")
                        df_pred = df_pred.sort_values("Date").dropna(subset=["Date"])
                        
                        # Find numeric columns, excluding 'Date'
                        numeric_cols_pred = df_pred.select_dtypes(include=["float64", "int64"]).columns.tolist()
                        for col in ["Date", "Days"]:
                             if col in numeric_cols_pred:
                                numeric_cols_pred.remove(col)

                        if not numeric_cols_pred:
                             st.warning("⚠️ No numeric columns found for prediction.")
                        else:
                            selected_params = st.multiselect("Select parameters to predict:", numeric_cols_pred, 
                                                            default=[p for p in ["pH", "TDS", "Turbidity"] if p in numeric_cols_pred])
                            future_days = st.slider("Forecast next N days:", 1, 30, 7)

                            regulatory_limits = {
                                "pH": (6.5, 8.5),
                                "TDS": (200, 500),
                                "Turbidity": (0, 5),
                                "Chlorine": (0.2, 1.0),
                                "Temperature": (0, 30),
                                "Conductivity": (0, 600),
                            }

                            future_results = pd.DataFrame({"Date": pd.date_range(df_pred["Date"].max() + pd.Timedelta(days=1),
                                                                                periods=future_days)})
                            alert_summary = {}
                            seq_len = 3

                            # Display progress bar while training/predicting
                            progress_text = "Training models and forecasting..."
                            prog_bar = st.progress(0, text=progress_text)
                            
                            for i, param in enumerate(selected_params):
                                prog_bar.progress((i + 1) / len(selected_params), text=f"Processing {param}...")
                                
                                if param not in df_pred.columns:
                                    continue
                                    
                                data = df_pred[[param]].dropna().values.astype(float)
                                
                                if len(data) < seq_len + 1:
                                    st.warning(f"Not enough clean data ({len(data)} points) to train a model for {param}.")
                                    continue

                                # Train or get cached model
                                model = train_xgb_model_for_param(data, st.session_state.user_email, param, seq_len=seq_len)
                                if model is None:
                                    st.warning(f"Could not build a predictive model for {param}.")
                                    continue

                                last_seq = data[-seq_len:].reshape(seq_len).tolist()
                                future_pred = []

                                for _ in range(future_days):
                                    x_input = np.array(last_seq[-seq_len:]).reshape(1, seq_len)
                                    pred = float(model.predict(x_input)[0])

                                    # Scenario adjustment (if scenario was enabled on the Dashboard tab)
                                    try:
                                        if enable_sim and param in scenario_inputs:
                                            adjustment = scenario_inputs[param]
                                            last_actual = df_pred[param].iloc[-1]
                                            if last_actual != 0:
                                                pct_change = (adjustment - last_actual) / last_actual
                                                pred = pred * (1 + pct_change)
                                            else:
                                                # If last value is 0, just use the adjustment value for the first forecast step
                                                pred = adjustment
                                    except NameError:
                                        # scenario_inputs not defined if tab1 was never rendered/used
                                        pass
                                    except KeyError:
                                        # param not in scenario_inputs
                                        pass

                                    future_pred.append(pred)
                                    last_seq.append(pred)

                                future_results[param] = future_pred

                                # Regulatory status
                                if param in regulatory_limits:
                                    low, high = regulatory_limits[param]
                                    future_results[f"{param}_Status"] = future_results[param].apply(
                                        lambda x: "⚠️ Out of Range" if x < low or x > high else "✅ Safe"
                                    )
                                    alert_summary[param] = future_results[f"{param}_Status"].value_counts().to_dict()

                            prog_bar.empty() # Clear progress bar
                            
                            if not future_results.empty:
                                with st.expander("📊 Future Predictions Table"):
                                    st.dataframe(future_results, use_container_width=True)

                                st.markdown("### 🚨 Future Risk Summary")
                                if alert_summary:
                                    for param, alerts in alert_summary.items():
                                        st.markdown(f"**{param}**: " + ", ".join([f"{k} ({v} days)" for k, v in alerts.items()]))
                                else:
                                    st.info("No parameters were successfully predicted or no regulatory limits were exceeded.")


                                st.markdown(f"### 📈 Prediction Chart for Next {future_days} Days")
                                fig = go.Figure()
                                colors_map = {
                                    "pH": "#28A745", "TDS": "#DC3545", "Turbidity": "#FF9800",
                                    "Chlorine": "#17A2B8", "Temperature": "#FFC107", "Conductivity": "#6C757D"
                                }

                                for param in selected_params:
                                    if param in future_results.columns:
                                        low, high = regulatory_limits.get(param, (None, None))
                                        bar_color = colors_map.get(param, "#6EE7B7")
                                        
                                        # Plot historical data (last 30 points for context)
                                        hist_data = df_pred[["Date", param]].tail(30).dropna()
                                        fig.add_trace(go.Scatter(x=hist_data["Date"], y=hist_data[param],
                                                                 mode='lines+markers', name=f"{param} (History)",
                                                                 line=dict(color=bar_color, dash='dash')))
                                                                 
                                        # Plot forecast
                                        fig.add_trace(go.Bar(x=future_results["Date"], y=future_results[param],
                                                             name=f"{param} (Forecast)", marker_color=bar_color, opacity=0.8))
                                                             
                                        if low and high:
                                            # Add safe range rectangle
                                            fig.add_hrect(y0=low, y1=high, line_width=0,
                                                          fillcolor="rgba(110, 231, 183, 0.15)", layer="below",
                                                          annotation_text="Safe Range", annotation_position="top left",
                                                          annotation_font_color="#6EE7B7")

                                fig.update_layout(plot_bgcolor='#FFFFFF', paper_bgcolor='#FFFFFF', font_color='#0A2342',
                                                    title_font_color='#0A2342', xaxis_title="Date", yaxis_title="Value",
                                                    barmode="group", xaxis=dict(showgrid=False, zeroline=False),
                                                    yaxis=dict(showgrid=True, zeroline=False, gridcolor='#E9ECEF'))
                                st.plotly_chart(fig, use_container_width=True)

                                csv_pred = future_results.to_csv(index=False).encode()
                                st.download_button("📥 Download Predictions as CSV", csv_pred, "water_predictions.csv", "text/csv")
                            else:
                                st.warning("Forecast could not be generated for the selected parameters.")


            # -------------------- TAB 4: AI Advisor --------------------
            with tab4:
                st.markdown("### 🤖 AI Advisor")
                st.write("Ask questions about your dataset in plain English.")
                if "chat_history" not in st.session_state:
                    st.session_state.chat_history = []

                # Ensure there is filtered data before allowing query
                if filtered_df.empty:
                    st.warning("Please select a dataset in the sidebar to enable the AI Advisor.")
                else:
                    with st.form(key="ai_form", clear_on_submit=True):
                        user_query = st.text_input("💬 Your Question", placeholder="e.g., Why is turbidity high this week?")
                        submit = st.form_submit_button("Ask AI")

                    if submit and user_query.strip():
                        with st.spinner("🤖 AI is analyzing your dataset..."):
                            # Filtered_df is passed to the AI advisor
                            answer = ask_ai_advisor(filtered_df, user_query)
                        st.session_state.chat_history.append(("user", user_query))
                        st.session_state.chat_history.append(("ai", answer))

                    # Display chat history in reverse order (newest at bottom)
                    for role, text in reversed(st.session_state.chat_history):
                        if role == "user":
                            st.markdown(f"<div class='user-bubble'><b>🧑 You:</b> {text}</div>", unsafe_allow_html=True)
                        else:
                            bubble_class = "ai-bubble"
                            if "⚠️" in text: bubble_class = "ai-bubble alert"
                            elif "✅" in text: bubble_class = "ai-bubble safe"
                            st.markdown(f"<div class='{bubble_class}'><b>🤖 AI:</b> {text}</div>", unsafe_allow_html=True)

            # -------------------- TAB 5: Anomaly Detection --------------------
            with tab5:
                st.markdown("### ⚠️ Anomaly Detection")
                # The `future_results` dataframe contains the forecast and status columns
                try:
                    # build_anomaly_ui relies on the parameters calculated in the Prediction tab
                    build_anomaly_ui(st.session_state.user_email, future_results, enable_sim, scenario_inputs)
                except NameError:
                    st.warning("Run the **Prediction** tab first to generate the necessary data for anomaly detection.")
                except Exception as e:
                    st.error(f"Error building anomaly UI: {e}")

    else:
        st.info("Upload or select a dataset from the sidebar to start the dashboard.")