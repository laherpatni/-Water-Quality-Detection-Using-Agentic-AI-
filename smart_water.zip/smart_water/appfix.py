import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import xgboost as xgb
import base64
import re
import os
import pickle
from ai_advisor import ask_ai_advisor, get_last_response_code
from anomaly import build_anomaly_ui
from database import create_user, authenticate_user, get_user, save_dataset, get_datasets, get_dataset_by_id

ENABLE_EMAIL = False

# -------------------- CONFIG --------------------
st.set_page_config(page_title="💧 Smart Water Dashboard", layout="wide", initial_sidebar_state="expanded")

# -------------------- MODEL CACHE DIR --------------------
MODEL_DIR = "/tmp/smart_water_models"
os.makedirs(MODEL_DIR, exist_ok=True)

# -------------------- BACKGROUND IMAGE --------------------
@st.cache_data
def get_base64_of_bin_file(bin_file):
    try:
        with open(bin_file, 'rb') as f:
            data = f.read()
        return base64.b64encode(data).decode()
    except FileNotFoundError:
        st.error(f"File not found: {bin_file}. Please ensure it is in the same directory as the script.")
        return None

background_image_path = 'water 2.jpg'
encoded_image = get_base64_of_bin_file(background_image_path)
if encoded_image:
    st.markdown(f"""
        <style>
        .stApp {{
            background-image: url("data:image/jpeg;base64,{encoded_image}");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }}
        header, .st-emotion-cache-6qob1r, .st-emotion-cache-18ni7ap {{
            display: none !important;
        }}

        </style>
        """, unsafe_allow_html=True)

# -------------------- SESSION --------------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user_email" not in st.session_state:
    st.session_state.user_email = ""
if "username" not in st.session_state:
    st.session_state.username = ""
if "auth_tab" not in st.session_state:
    st.session_state.auth_tab = "Login"

# -------------------- HELPER FUNCTIONS --------------------
@st.cache_data
def load_combined_user_data(user_email: str):
    try:
        user_datasets = get_datasets(user_email)
        combined_df = pd.DataFrame()
        for d in user_datasets:
            try:
                df_temp, _ = get_dataset_by_id(d['id'])
                if isinstance(df_temp, pd.DataFrame) and not df_temp.empty:
                    combined_df = pd.concat([combined_df, df_temp], ignore_index=True)
            except Exception:
                continue
        if not combined_df.empty:
            combined_df = combined_df.reset_index(drop=True)
        return combined_df
    except Exception as e:
        return pd.DataFrame()

def _model_filename_for(user_email: str, param: str, n_rows: int, last_val: float, seq_len: int):
    safe_email = re.sub(r'[^0-9a-zA-Z]+', '_', user_email)
    safe_param = re.sub(r'[^0-9a-zA-Z]+', '_', param)
    fname = f"xgb_{safe_email}_{safe_param}_n{n_rows}_last{round(float(last_val),6)}_s{seq_len}.pkl"
    return os.path.join(MODEL_DIR, fname)

def train_xgb_model_for_param(data: np.ndarray, user_email: str, param: str, seq_len: int = 3):
    if data is None or len(data) < seq_len + 1:
        return None
    n_rows = len(data)
    last_val = float(data[-1, 0])
    model_path = _model_filename_for(user_email, param, n_rows, last_val, seq_len)
    if os.path.exists(model_path):
        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)
            return model
        except Exception:
            pass
    X, y = [], []
    for i in range(seq_len, len(data)):
        X.append(data[i - seq_len:i, 0])
        y.append(data[i, 0])
    X = np.array(X)
    y = np.array(y)
    if len(X) == 0:
        return None
    model = xgb.XGBRegressor(n_estimators=200, max_depth=3, learning_rate=0.1, verbosity=0)
    model.fit(X, y)
    try:
        with open(model_path, "wb") as f:
            pickle.dump(model, f)
    except Exception:
        pass
    return model

# -------------------- STYLES --------------------
st.markdown("""
<style>
/* Full page blue background */
.stApp {background-color: #E5F2FF; color: #0A2342;}

/* AUTH CARD */
.auth-root {display: flex; justify-content: center; align-items: center; height: 100vh; padding: 0 20px; box-sizing: border-box;}
.auth-card {width: 100%; max-width: 500px; min-width: 320px; background: #ffffff; border-radius: 20px; padding: 30px 30px; box-shadow: 0 18px 50px rgba(8,30,60,0.12); border: 1px solid rgba(10,35,66,0.08); text-align: center;}
.auth-brand {display:flex; align-items:center; gap:12px; margin-bottom:20px; justify-content: center;}
.auth-brand-icon {font-size:28px; width:60px; height:60px; display:flex; align-items:center; justify-content:center; border-radius:15px; background: linear-gradient(180deg, #EAF0FF 0%, #F7F9FF 100%); box-shadow: 0 6px 18px rgba(45,55,110,0.06);}
.auth-title {font-size:22px; font-weight:800; margin:0;}
.auth-sub {margin-top:2px; color:#687182; font-size:14px;}
.auth-toggle {display:flex; justify-content:center; gap:12px; margin:20px 0;}
.auth-toggle button {padding:10px 22px; border-radius:15px; font-weight:700; cursor:pointer; border: 1px solid transparent; background: transparent; color: #475569; transition: all 0.2s ease;}
.auth-toggle .active {background: linear-gradient(90deg,#5D5BFF,#4B47E0); color: white; box-shadow: 0 8px 20px rgba(93,91,255,0.12);}
.auth-card .stTextInput>div>div>input, .auth-card .stTextArea>div>div>textarea {border-radius:12px; padding:12px 14px; border:1px solid #D1D9E6; width:100%; margin:8px 0; box-sizing:border-box;}
.auth-card .stButton>button {border-radius:12px; padding:14px 18px; background: linear-gradient(90deg,#5D5BFF,#4B47E0); color:white; font-weight:700; border:none; width:100%; margin:14px 0; cursor:pointer; font-size:16px; transition: transform 0.1s ease;}
.auth-card .stButton>button:hover {transform: scale(1.02);}

...
(ALL REMAINING CODE IS EXACTLY THE SAME)
...

@media (max-width: 600px) {.auth-card {width: 90vw; padding: 20px;} .auth-card .stButton>button, .auth-card .stTextInput>div>div>input {width: 100%;}}

/* KPI cards & chat bubbles */
.kpi-grid {display:flex; flex-wrap: wrap; gap: 18px; margin-bottom:25px;}
.kpi-card {flex:1; min-width:150px; background:#F5F5F5; padding:12px; border-radius:12px; box-shadow:2px 2px 8px #CCC; text-align:center;}
.kpi-alert-card {background:#F8D7DA;}
.kpi-safe-card {background:#D4EDDA;}
.kpi-title {font-size:16px; font-weight:bold; margin-bottom:6px;}
.kpi-value {font-size:24px; font-weight:bold;}
.kpi-trend {font-size:18px;}
.kpi-minmax {font-size:12px; color:#555;}
.user-bubble {background:#E1F5FE; padding:12px; border-radius:12px; margin:6px 0;}
.ai-bubble {background:#FFF3CD; padding:12px; border-radius:12px; margin:6px 0;}
.ai-bubble.alert {background:#F8D7DA;}
.ai-bubble.safe {background:#D4EDDA;}
.dashboard-title {font-size:30px; font-weight:bold; text-align:center; margin-bottom:25px;}
            
            /* REMOVE DEFAULT STREAMLIT TOP BLOCK (PURPLE BOX) */
header, .st-emotion-cache-6qob1r, .st-emotion-cache-18ni7ap {
    display: none !important;
}

/* REMOVE STREAMLIT MAIN PADDING AREA (WHITE CONTAINER) */
main .block-container {
    padding-top: 0 !important;
    margin-top: 0 !important;
}

/* REMOVE STREAMLIT MAIN BACKGROUND BOX COMPLETELY */
.css-1d391kg, .st-emotion-cache-1y4p8pa, .st-emotion-cache-1wivap2 {
    background: transparent !important;
    box-shadow: none !important;
}
</style>
            
      

""", unsafe_allow_html=True)

# -------------------- AUTH UI --------------------
def auth_start_page():
    st.markdown("<div class='auth-root'>", unsafe_allow_html=True)
    st.markdown("<div class='auth-card'>", unsafe_allow_html=True)

    st.markdown("""
        <div class='auth-brand'>
            <div class='auth-brand-icon'>💧</div>
            <div>
                <div class='auth-title'>Smart Water Dashboard</div>
                <div class='auth-sub'>Monitor, predict and advise — secure & private</div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    cols = st.columns([1,1])
    with cols[0]:
        if st.button("Login", key="auth_login_btn"):
            st.session_state.auth_tab = "Login"
    with cols[1]:
        if st.button("Signup", key="auth_signup_btn"):
            st.session_state.auth_tab = "Signup"

    st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

    # LOGIN FORM
    if st.session_state.auth_tab == "Login":
        st.markdown("<h3 style='margin:4px 0 10px 0'>Welcome back</h3>", unsafe_allow_html=True)
        st.markdown("<div class='auth-sub'>Log in to access your dashboard and datasets</div>", unsafe_allow_html=True)

        with st.form("login_form_card", clear_on_submit=False):
            email = st.text_input("Email", placeholder="you@example.com")
            password = st.text_input("Password", type="password", placeholder="At least 8 characters")
            submit = st.form_submit_button("Sign in", use_container_width=True)

        if submit:
            if not email or not password:
                st.error("Please provide both email and password.")
            else:
                ok = authenticate_user(email.strip().lower(), password)
                if ok:
                    st.success("Login successful — redirecting to dashboard...")
                    st.session_state.logged_in = True
                    st.session_state.user_email = email.strip().lower()
                    user_doc = get_user(st.session_state.user_email)
                    st.session_state.username = user_doc.get("username", st.session_state.user_email.split("@")[0])
                    st.experimental_rerun()
                else:
                    st.error("Invalid email or password. If you don't have an account, create one.")

    # SIGNUP FORM
    else:
        st.markdown("<h3 style='margin:4px 0 10px 0'>Create an account</h3>", unsafe_allow_html=True)
        st.markdown("<div class='auth-sub'>Start tracking water quality — secure and private</div>", unsafe_allow_html=True)

        with st.form("signup_form_card", clear_on_submit=False):
            username = st.text_input("Full name", placeholder="Rohan Patil")
            email = st.text_input("Email", placeholder="you@example.com")
            password = st.text_input("Password", type="password", placeholder="At least 8 characters")
            confirm = st.text_input("Confirm Password", type="password")
            submit = st.form_submit_button("Create account", use_container_width=True)

        if submit:
            if not username.strip():
                st.error("Please enter your full name.")
            elif not email.strip():
                st.error("Please enter an email.")
            elif not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email.strip()):
                st.error("Please enter a valid email address.")
            elif not password or len(password) < 8:
                st.error("Password must be at least 8 characters long.")
            elif password != confirm:
                st.error("Passwords do not match.")
            else:
                created = create_user(username.strip(), email.strip().lower(), password)
                if not created:
                    st.error("An account with that email already exists. Try logging in.")
                else:
                    st.success("Account created! You are now logged in.")
                    st.session_state.logged_in = True
                    st.session_state.user_email = email.strip().lower()
                    st.session_state.username = username.strip()
                    st.experimental_rerun()

    st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)

# -------------------- AUTH FLOW --------------------
if not st.session_state.logged_in:
    auth_start_page()

# -------------------- DASHBOARD --------------------
if st.session_state.logged_in:
    display_name = get_user(st.session_state.user_email).get("username", st.session_state.user_email.split("@")[0])
    st.sidebar.success(f"Logged in as {display_name}")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.user_email = ""
        st.session_state.username = ""
        st.session_state.auth_tab = "Login"
        st.experimental_rerun()

    # --- FILE UPLOAD, Dataset selection, KPIs, Prediction, AI advisor, Anomaly UI ---
    # Keep your existing dashboard code here (as in original file)
    # Nothing changes in dashboard functionality


    # -------------------- FILE UPLOAD --------------------
    st.sidebar.markdown("### Upload Water Quality Data")
    uploaded_file = st.file_uploader("Choose a CSV or Excel file", type=["csv", "xls", "xlsx"])

    df = None
    if uploaded_file:
        if uploaded_file.name.endswith(".csv"):
            df = pd.read_csv(uploaded_file)
        elif uploaded_file.name.endswith((".xls", ".xlsx")):
            df = pd.read_excel(uploaded_file)

        # Save dataset to MongoDB
        try:
            dataset_id = save_dataset(st.session_state.user_email, uploaded_file.name, df)
            st.success(f"Dataset saved to your account (ID: {dataset_id})")
            # clear model cache directory for this user to force retrain next time (simple approach)
            # remove files matching this user
            try:
                for fname in os.listdir(MODEL_DIR):
                    if re.sub(r'[^0-9a-zA-Z]+', '_', st.session_state.user_email) in fname:
                        fullp = os.path.join(MODEL_DIR, fname)
                        try:
                            os.remove(fullp)
                        except Exception:
                            pass
            except Exception:
                pass
        except Exception as e:
            st.error(f"Error saving dataset: {e}")

    # -------------------- USER DATASETS --------------------
    st.sidebar.markdown("### Your Saved Datasets")
    try:
        user_datasets = get_datasets(st.session_state.user_email)
    except Exception as e:
        st.error(f"Error fetching datasets: {e}")
        user_datasets = []

    selected_dataset_name = st.sidebar.selectbox("Select a dataset", ["--Select--"] + [d['filename'] for d in user_datasets])
    if selected_dataset_name != "--Select--":
        for d in user_datasets:
            if d['filename'] == selected_dataset_name:
                try:
                    df, filename = get_dataset_by_id(d['id'])
                    st.info(f"Loaded dataset: {filename}")
                except Exception as e:
                    st.error(f"Error loading dataset: {e}")
                    df = None

    # -------------------- DASHBOARD CODE (UNCHANGED) --------------------
    if df is not None:
        # ----- Data Loading and Summary Functions -----
        @st.cache_data
        def get_summary(df):
            return df.describe(include="all").transpose(), df.isnull().sum()

        # ----- KPI DISPLAY FUNCTION -----
        def display_kpis(df, scenario_inputs=None):
            st.markdown("### 📊 Key Water Quality Metrics")
            numeric_cols = df.select_dtypes(include=["int64", "float64"]).columns.tolist()
            if not numeric_cols:
                st.info("No numeric columns to display as KPIs.")
                return
            st.markdown('<div class="kpi-grid">', unsafe_allow_html=True)
            regulatory_limits = {
                "pH": (6.5, 8.5),
                "TDS": (200, 500),
                "Turbidity": (0, 5),
                "Chlorine": (0.2, 1.0),
                "Temperature": (0, 30),
                "Conductivity": (0, 600)
            }
            for col in numeric_cols:
                col_data = df[col].dropna()
                if len(col_data) == 0:
                    continue
                latest_val = float(col_data.iloc[-1])
                if scenario_inputs and col in scenario_inputs:
                    latest_val = scenario_inputs[col]
                prev_val = float(col_data.iloc[-2]) if len(col_data) > 1 else latest_val
                trend = "↑" if latest_val > prev_val else "↓" if latest_val < prev_val else "→"
                card_class = "kpi-card"
                text_class = ""
                limits = None
                for key in regulatory_limits.keys():
                    if key.lower() == col.lower().strip():
                        limits = regulatory_limits[key]
                        break
                if limits:
                    low, high = limits
                    if latest_val < low or latest_val > high:
                        card_class += " kpi-alert-card"
                        text_class = "kpi-alert-text"
                    else:
                        card_class += " kpi-safe-card"
                        text_class = "kpi-safe-text"
                st.markdown(f"""
                <div class="{card_class}">
                    <div class="kpi-title {text_class}">{col}</div>
                    <div class="kpi-value">{latest_val:.2f}</div>
                    <div class="kpi-trend">{trend}</div>
                    <div class="kpi-minmax">Min:{col_data.min():.2f} | Max:{col_data.max():.2f} | Avg:{col_data.mean():.2f}</div>
                </div>
                """, unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        # ----- Sidebar and Tabs -----
        with st.container(border=False):
            st.markdown('<div class="dashboard-title">💧 Smart Water Dashboard</div>', unsafe_allow_html=True)
            tab1, tab2, tab3, tab4, tab5 = st.tabs(["Upload Data", "Dashboard", "Prediction", "AI Advisor", "Anomaly Detection"])

            # -------------------- TAB 1: Dashboard & KPIs --------------------
            with tab1:
                if "Date" in df.columns:
                    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
                    min_date, max_date = df["Date"].min(), df["Date"].max()
                    selected_range = st.date_input("Select Date Range", [min_date, max_date])
                    filtered_df = df[(df["Date"] >= pd.to_datetime(selected_range[0])) & (df["Date"] <= pd.to_datetime(selected_range[1]))]
                else:
                    filtered_df = df.copy()

                scenario_inputs = {}
                enable_sim = st.checkbox("Enable Scenario Simulation", value=False)
                if enable_sim:
                    st.markdown("### 🔧 Scenario Simulation")
                    numeric_cols = filtered_df.select_dtypes(include=["int64", "float64"]).columns.tolist()
                    kpi_cols = numeric_cols[:4]
                    for param in kpi_cols:
                        min_val, max_val = filtered_df[param].min(), filtered_df[param].max()
                        scenario_inputs[param] = st.slider(f"Adjust {param}", float(min_val), float(max_val), float(filtered_df[param].iloc[-1]))

                display_kpis(filtered_df, scenario_inputs)

                # Charts
                st.markdown("### 📈 Data Visualization")
                chart_type = st.selectbox("Choose chart type:", ["Line", "Bar", "Scatter", "Box", "Heatmap"])
                all_cols = filtered_df.columns.tolist()
                numeric_cols = filtered_df.select_dtypes(include=["int64", "float64"]).columns.tolist()

                if chart_type != "Heatmap":
                    x_axis = st.selectbox("X-axis", all_cols)
                    y_axis = st.selectbox("Y-axis", numeric_cols)

                if st.button("Generate Chart"):
                    viz_df = filtered_df.sample(2000, random_state=42) if len(filtered_df) > 2000 else filtered_df
                    if chart_type == "Line":
                        fig = px.line(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} over {x_axis}", markers=True)
                    elif chart_type == "Bar":
                        fig = px.bar(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} by {x_axis}")
                    elif chart_type == "Scatter":
                        fig = px.scatter(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} vs {x_axis}", trendline="ols")
                    elif chart_type == "Box":
                        fig = px.box(viz_df, x=x_axis, y=y_axis, title=f"{y_axis} Distribution by {x_axis}")
                    elif chart_type == "Heatmap":
                        corr = viz_df.corr(numeric_only=True)
                        fig = px.imshow(corr, text_auto=True, color_continuous_scale="Blues", title="Correlation Heatmap")

                    fig.update_layout(plot_bgcolor='#FFFFFF', paper_bgcolor='#FFFFFF', font_color='#0A2342',
                                      title_font_color='#0A2342', xaxis=dict(showgrid=False, zeroline=False),
                                      yaxis=dict(showgrid=True, zeroline=False, gridcolor='#E9ECEF'))
                    st.plotly_chart(fig, use_container_width=True)

            # -------------------- TAB 2: Data Preview & Summary --------------------
            with tab2:
                st.markdown("### 📋 Data Preview & Summary")
                with st.expander("Show Raw Data"):
                    st.dataframe(filtered_df, use_container_width=True)

                summary_stats, missing_values = get_summary(filtered_df)
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("### Column Types")
                    st.write(filtered_df.dtypes)
                with col2:
                    st.markdown("### Missing Values")
                    st.write(missing_values)

                with st.expander("Show Summary Statistics"):
                    st.dataframe(summary_stats, use_container_width=True)

                st.markdown("### 📥 Download Filtered Data")
                csv = filtered_df.to_csv(index=False).encode("utf-8")
                st.download_button("⬇️ Download Filtered Data as CSV", csv, "filtered_data.csv", "text/csv")

            # -------------------- TAB 3: AI Prediction (combined datasets + cached models) --------------------
            with tab3:
                st.markdown("### 🔮 AI Water Quality Prediction (XGBoost)")

                # Combine all user datasets (not just selected dataset) for prediction
                MAX_ROWS = 5000
                combined_df = load_combined_user_data(st.session_state.user_email)

                if combined_df.empty:
                    st.warning("⚠️ No dataset available for prediction. Upload data first.")
                else:
                    df_pred = combined_df.tail(MAX_ROWS).copy() if len(combined_df) > MAX_ROWS else combined_df.copy()

                    if "Date" not in df_pred.columns:
                        st.warning("⚠️ Prediction requires a 'Date' column.")
                    else:
                        df_pred["Date"] = pd.to_datetime(df_pred["Date"], errors="coerce")
                        df_pred = df_pred.sort_values("Date").dropna()
                        df_pred["Days"] = (df_pred["Date"] - df_pred["Date"].min()).dt.days

                        # Select numeric parameters for prediction
                        numeric_cols = df_pred.select_dtypes(include=["float64", "int64"]).columns.tolist()
                        for col in ["Date", "Days"]:
                            if col in numeric_cols:
                                numeric_cols.remove(col)

                        if numeric_cols:
                            selected_params = st.multiselect("Select parameters to predict:", numeric_cols, default=numeric_cols)
                            future_days = st.slider("Forecast next N days:", 1, 30, 7)

                            regulatory_limits = {
                                "pH": (6.5, 8.5),
                                "TDS": (200, 500),
                                "Turbidity": (0, 5),
                                "Chlorine": (0.2, 1.0),
                                "Temperature": (0, 30),
                                "Conductivity": (0, 600),
                                # you can add or edit limits here
                            }

                            future_results = pd.DataFrame({"Date": pd.date_range(df_pred["Date"].max() + pd.Timedelta(days=1),
                                                                                periods=future_days)})
                            alert_summary = {}
                            seq_len = 3

                            for param in selected_params:
                                # ensure column exists and numeric
                                if param not in df_pred.columns:
                                    continue
                                data = df_pred[[param]].values.astype(float)

                                # Train or get cached model
                                model = train_xgb_model_for_param(data, st.session_state.user_email, param, seq_len=seq_len)
                                if model is None:
                                    st.warning(f"Not enough data to train a model for {param}.")
                                    continue

                                last_seq = data[-seq_len:].reshape(seq_len).tolist()
                                future_pred = []

                                for _ in range(future_days):
                                    x_input = np.array(last_seq[-seq_len:]).reshape(1, seq_len)
                                    pred = float(model.predict(x_input)[0])

                                    # Scenario simulation adjustment (if scenario enabled on dashboard tab)
                                    # We rely on scenario_inputs & enable_sim defined earlier in tab1 context
                                    # If not present, fallback to no adjustment.
                                    try:
                                        if enable_sim:
                                            adjustment = scenario_inputs.get(param, df_pred[param].iloc[-1])
                                            if df_pred[param].iloc[-1] != 0:
                                                pct_change = (adjustment - df_pred[param].iloc[-1]) / df_pred[param].iloc[-1]
                                                pred = pred * (1 + pct_change)
                                            else:
                                                pred = adjustment
                                    except Exception:
                                        # if scenario_inputs not defined in this scope, skip adjustment
                                        pass

                                    future_pred.append(pred)
                                    last_seq.append(pred)

                                future_results[param] = future_pred

                                # Regulatory status
                                if param in regulatory_limits:
                                    low, high = regulatory_limits[param]
                                    future_results[f"{param}_Status"] = future_results[param].apply(
                                        lambda x: "⚠️ Out of Range" if x < low or x > high else "✅ Safe"
                                    )
                                    alert_summary[param] = future_results[f"{param}_Status"].value_counts().to_dict()

                            with st.expander("📊 Future Predictions Table"):
                                st.dataframe(future_results, use_container_width=True)

                            st.markdown("### 🚨 Future Risk Summary")
                            for param, alerts in alert_summary.items():
                                st.markdown(f"**{param}**: " + ", ".join([f"{k}={v}" for k, v in alerts.items()]))

                            st.markdown(f"### 📈 Prediction Chart for Next {future_days} Days")
                            fig = go.Figure()
                            colors_map = {
                                "pH": "#28A745", "TDS": "#DC3545", "Turbidity": "#FF9800",
                                "Chlorine": "#17A2B8", "Temperature": "#FFC107", "Conductivity": "#6C757D"
                            }

                            for param in selected_params:
                                if param in future_results.columns:
                                    low, high = regulatory_limits.get(param, (None, None))
                                    bar_color = colors_map.get(param, "#6EE7B7")
                                    fig.add_trace(go.Bar(x=future_results["Date"], y=future_results[param],
                                                         name=f"{param} (Forecast)", marker_color=bar_color))
                                    if low and high:
                                        fig.add_hrect(y0=low, y1=high, line_width=0,
                                                      fillcolor="rgba(110, 231, 183, 0.15)", layer="below",
                                                      annotation_text="Safe Range", annotation_position="top left",
                                                      annotation_font_color="#6EE7B7")

                            fig.update_layout(plot_bgcolor='#FFFFFF', paper_bgcolor='#FFFFFF', font_color='#0A2342',
                                              title_font_color='#0A2342', xaxis_title="Date", yaxis_title="Value",
                                              barmode="group", xaxis=dict(showgrid=False, zeroline=False),
                                              yaxis=dict(showgrid=True, zeroline=False, gridcolor='#E9ECEF'))
                            st.plotly_chart(fig, use_container_width=True)

                            csv_pred = future_results.to_csv(index=False).encode()
                            st.download_button("📥 Download Predictions as CSV", csv_pred, "water_predictions.csv", "text/csv")

            # -------------------- TAB 4: AI Advisor --------------------
            with tab4:
                st.markdown("### 🤖 AI Advisor")
                st.write("Ask questions about your dataset in plain English.")
                if "chat_history" not in st.session_state:
                    st.session_state.chat_history = []

                with st.form(key="ai_form", clear_on_submit=True):
                    user_query = st.text_input("💬 Your Question", placeholder="e.g., Why is turbidity high this week?")
                    submit = st.form_submit_button("Ask AI")

                if submit and user_query.strip():
                    with st.spinner("🤖 AI is analyzing your dataset..."):
                        answer = ask_ai_advisor(filtered_df, user_query)
                    st.session_state.chat_history.append(("user", user_query))
                    st.session_state.chat_history.append(("ai", answer))

                for role, text in st.session_state.chat_history:
                    if role == "user":
                        st.markdown(f"<div class='user-bubble'><b>🧑 You:</b> {text}</div>", unsafe_allow_html=True)
                    else:
                        bubble_class = "ai-bubble"
                        if "⚠️" in text: bubble_class = "ai-bubble alert"
                        elif "✅" in text: bubble_class = "ai-bubble safe"
                        st.markdown(f"<div class='{bubble_class}'><b>🤖 AI:</b> {text}</div>", unsafe_allow_html=True)

                tab5 = st.tabs(["⚠️ Anomalies & Alerts"])
                with tab5[0]:
                    # keep anomaly UI call the same
                    try:
                        build_anomaly_ui(st.session_state.user_email, future_results, enable_sim, scenario_inputs)
                    except Exception:
                        # If future_results or scenario_inputs not available, anomaly UI will handle it gracefully.
                        pass

    else:
        st.info("Upload or select a dataset to start the dashboard.")

# -------------------- STYLES (rest of app) --------------------
# (the main styles were already embedded above; keep them to ensure KPI and chat bubbles render consistently)
# No further style changes are made to dashboard to preserve original look & feel.


# -------------------- STYLES (rest of app) --------------------
st.markdown("""
<style>
.kpi-grid {display:flex; flex-wrap: wrap; gap: 15px; margin-bottom:20px;}
.kpi-card {flex:1; min-width:150px; background:#F5F5F5; padding:10px; border-radius:10px; box-shadow:2px 2px 5px #CCC; text-align:center;}
.kpi-alert-card {background:#F8D7DA;}
.kpi-safe-card {background:#D4EDDA;}
.kpi-title {font-size:16px; font-weight:bold; margin-bottom:5px;}
.kpi-value {font-size:24px; font-weight:bold;}
.kpi-trend {font-size:18px;}
.kpi-minmax {font-size:12px; color:#555;}
.user-bubble {background:#E1F5FE; padding:10px; border-radius:10px; margin:5px 0;}
.ai-bubble {background:#FFF3CD; padding:10px; border-radius:10px; margin:5px 0;}
.ai-bubble.alert {background:#F8D7DA;}
.ai-bubble.safe {background:#D4EDDA;}
.dashboard-title {font-size:28px; font-weight:bold; text-align:center; margin-bottom:20px;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>

/* REMOVE white full-screen overlay */
.stApp::before {
    background: transparent !important;
}

/* REMOVE purple Streamlit header bar */
header, .st-emotion-cache-18ni7ap {
    display: none !important;
}

/* REMOVE default top padding that creates the big white block */
.block-container {
    padding-top: 0 !important;
}

</style>
""", unsafe_allow_html=True)

