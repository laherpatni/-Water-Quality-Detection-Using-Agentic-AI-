# database.py
from pymongo import MongoClient
from bson.objectid import ObjectId
from werkzeug.security import generate_password_hash, check_password_hash

# -------------------- CONFIGURATION --------------------
MONGO_URI = "mongodb://localhost:27017"  # Change if using MongoDB Atlas
DB_NAME = "smart_water_db"

# Connect to MongoDB
client = MongoClient(MONGO_URI)
db = client[DB_NAME]
users_col = db["users"]  # Collection for user authentication
data_col = db["datasets"]  # Optional collection for uploaded datasets

# -------------------- USER FUNCTIONS --------------------

def create_user(username: str, email: str, password: str) -> bool:
    """
    Create a new user with hashed password.
    Returns True if successful, False if email already exists.
    """
    if users_col.find_one({"email": email}):
        return False  # Email already exists
    hashed_password = generate_password_hash(password)
    users_col.insert_one({
        "username": username,
        "email": email,
        "password": hashed_password
    })
    return True

def authenticate_user(email: str, password: str) -> bool:
    """
    Authenticate user by email and password.
    Returns True if credentials are correct.
    """
    user = users_col.find_one({"email": email})
    if user and check_password_hash(user["password"], password):
        return True
    return False

def get_user(email: str):
    """
    Retrieve user information by email.
    """
    return users_col.find_one({"email": email}, {"password": 0})  # Exclude password

# -------------------- OPTIONAL: DATASET FUNCTIONS --------------------

def save_dataset(user_email: str, filename: str, df) -> str:
    """
    Save uploaded dataset to MongoDB (as CSV string).
    Returns dataset ID.
    """
    csv_data = df.to_csv(index=False)
    result = data_col.insert_one({
        "user_email": user_email,
        "filename": filename,
        "data": csv_data
    })
    return str(result.inserted_id)

def get_datasets(user_email: str):
    """
    Retrieve all datasets uploaded by a user.
    """
    datasets = data_col.find({"user_email": user_email})
    return [{"id": str(d["_id"]), "filename": d["filename"]} for d in datasets]

def get_dataset_by_id(dataset_id: str):
    """
    Retrieve a dataset by its MongoDB ID.
    """
    data = data_col.find_one({"_id": ObjectId(dataset_id)})
    if data:
        import pandas as pd
        from io import StringIO
        df = pd.read_csv(StringIO(data["data"]))
        return df, data["filename"]
    return None, None
