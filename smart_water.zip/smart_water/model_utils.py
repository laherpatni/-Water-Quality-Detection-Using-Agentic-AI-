# model_utils.py
import pandas as pd
import numpy as np
import xgboost as xgb
from database import get_datasets, get_dataset_by_id
from sklearn.model_selection import train_test_split

# -------------------- Train XGBoost model for a single parameter --------------------
def train_xgb_model_for_param(data, seq_len=3):
    """
    Trains an XGBoost model using past `seq_len` observations to predict the next value.

    Args:
        data (numpy array or list): 1D array of past values
        seq_len (int): Number of previous points to consider

    Returns:
        model: trained XGBoost model
    """
    if len(data) <= seq_len:
        return None  # Not enough data to train

    # Prepare sequences
    X, y = [], []
    for i in range(len(data) - seq_len):
        X.append(data[i:i+seq_len])
        y.append(data[i+seq_len])
    X, y = np.array(X), np.array(y)

    model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=100)
    model.fit(X, y)
    return model

# -------------------- Load and combine all user datasets --------------------
def load_combined_user_data(user_email):
    """
    Combines all datasets uploaded by the user into a single DataFrame.

    Args:
        user_email (str): user email

    Returns:
        pd.DataFrame: Combined DataFrame
    """
    combined_df = pd.DataFrame()
    try:
        user_datasets = get_datasets(user_email)
        for d in user_datasets:
            df, _ = get_dataset_by_id(d['id'])
            combined_df = pd.concat([combined_df, df], ignore_index=True)
    except Exception as e:
        print(f"Error loading user data: {e}")
    return combined_df
