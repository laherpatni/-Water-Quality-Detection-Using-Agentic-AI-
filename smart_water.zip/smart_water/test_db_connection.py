from database import users_col

try:
    print("Users collection count:", users_col.count_documents({}))
    print("MongoDB connection successful ✔️")
except Exception as e:
    print("Error:", e)
